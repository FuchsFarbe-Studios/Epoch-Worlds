FlatifyCSS website is created with [Docusaurus](https://github.com/facebook/docusaurus).  
To contribute and improve the newest version of documentation please check the `/website/docs` directory.
