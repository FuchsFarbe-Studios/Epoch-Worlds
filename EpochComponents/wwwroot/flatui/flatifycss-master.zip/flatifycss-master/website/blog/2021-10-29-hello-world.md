---
slug: hello-world
title: Hello World!
authors: [amir2mi]
tags: []
---

This is the first blog post from the FlatifyCSS website, heads-up! we will have lots of work to do here.
