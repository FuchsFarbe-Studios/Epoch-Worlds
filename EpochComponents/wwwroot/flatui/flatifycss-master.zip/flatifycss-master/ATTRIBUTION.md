## Icons

### the Noun Project

Quote by Untashable from the Noun Project  
Close by Jaro Sigrist from the Noun Project  
Warning by Deylotus Creative Design from the Noun Project  
done by Andrejs Kirma from the Noun Project  
fire by Giuditta Valentina Gentilefrom the Noun Project  
Eye by Royyan Wijaya from the Noun Project  
Arrow by wahyakup from the Noun Project  
Heart by BomSymbols from the Noun Project  
Brain by Adrien Coquet from the Noun Project  
Fullscreen by Landan Lloyd from the Noun Project  
Exit Fullscreen by Sophia Bai from the Noun Project  
Search by Graphik Designz from the Noun Project  
Check by James Kocsis from the Noun Project
Heart by BomSymbols from NounProject.com
Share by shaurya from NounProject.com
Coffee by Adrien Coquet from NounProject.com

### Flaticon

Flat check icon made by Freepik from flaticon.com  
Flat decline icon made by Freepik from flaticon.com
Tile icon made by Pixel perfect from flaticon.com
Screwdriver icon made by Pixel perfect from flaticon.com
Web Page icon made by Pixel perfect from flaticon.com

## Illustrations

### Icon8

Virtual reality by Murat Kalkavan from Ouch!  
Online art course by Tatyana Krasutskaya from Ouch!  
Logged out by Murat Kalkavan from Ouch!  
Molecular chain by Victoria Chepkasova from Ouch!
